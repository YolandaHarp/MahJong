import javax.swing.*;
import java.awt.*;

public class GameScreen extends JPanel {
    String[] table = new String[]{"一筒", "二筒", "三筒", "四筒", "五筒", "六筒", "七筒", "八筒", "九筒",
            "一条", "二条", "三条", "四条", "五条", "六条", "七条", "八条", "九条",
            "一万", "二万", "三万", "四万", "五万", "六万", "七万", "八万", "九万", "东", "南", "西",
            "北", "中", "発", "白", "混"};//从0开始数
    private int x = 50;
    private int y = 50;
    private int a = 1;

    void drawPg(Graphics g, int[] x_coords, int[] y_coords, int x, int y, double a, Color color1, Color color2, float f) {
        Graphics2D g2d = (Graphics2D) g;
        Stroke oldStroke = g2d.getStroke();
        Stroke newStroke = new BasicStroke((float) (f * a));
        g2d.setStroke(newStroke);
        int[] x_adjusted = new int[x_coords.length];
        int[] y_adjusted = new int[y_coords.length];
        for (int i = 0; i < x_coords.length; i++) {
            x_adjusted[i] = (int) (x + x_coords[i] * a);
            y_adjusted[i] = (int) (y + y_coords[i] * a);
        }
        Polygon pg = new Polygon(x_adjusted, y_adjusted, x_adjusted.length);
        g.setColor(color1);
        g.fillPolygon(pg);
        g.setColor(color2);
        g.drawPolygon(pg);
        g2d.setStroke(oldStroke);
    }

    void drawO(Graphics g, int x, int y, int i, int j, int h, double a, Color color1, Color color2, float f) {
        Graphics2D g2d = (Graphics2D) g;
        Stroke oldStroke = g2d.getStroke();
        Stroke newStroke = new BasicStroke((float) (f * a));
        g2d.setStroke(newStroke);
        g.setColor(color1);
        g.fillOval((int) (x - (500 - i) * a), (int) (y - (500 - j) * a), (int) (h * a), (int) (h * a));
        g.setColor(color2);
        g.drawOval((int) (x - (500 - i) * a), (int) (y - (500 - j) * a), (int) (h * a), (int) (h * a));
        g2d.setStroke(oldStroke);
    }

    void drawDown(Graphics g, int x, int y, double a) {
        int[] x_coords = new int[]{-13, -9, -13, -13, -9, 9, 13, 13, 9, 13, 13, 9, -9, -13, -13};
        int[] y_coords = new int[]{-40, -44, -48, -40, -44, -44, -48, -40, -44, -40, 20, 24, 24, 20, -40};
        drawPg(g, x_coords, y_coords, x, y, a, new Color(80, 180, 30), Color.WHITE, 1.0f);


    }

    void drawDownRight(Graphics g, int x, int y, double a) {
        drawDown(g, x, y, a);

    }

    void drawCardFlank(Graphics g, int x, int y, double a) {
        int[] x_coords = new int[]{30, 34, 34, 30, -30, -34, -34, -30};
        int[] y_coords = new int[]{48, 44, -44, -48, -48, -44, 44, 48};
        drawPg(g, x_coords, y_coords, x, y, a, new Color(100, 200, 50), Color.WHITE, 1.0f);
    }

    void drawCardUpper(Graphics g, int x, int y, double a) {
        int[] x_coords = new int[]{9, 13, 13, 9, -9, -13, -13, -9};
        int[] y_coords = new int[]{-82, -78, -48, -44, -44, -48, -78, -82};
        drawPg(g, x_coords, y_coords, x, y, a, new Color(100, 200, 50), Color.WHITE, 1.0f);
    }

    void drawCardUpperLeft(Graphics g, int x, int y, double a) {
        drawCardUpper(g, x, y, a);
        int[] x_coords = new int[]{-9, -13, -13, -9};
        int[] y_coords = new int[]{-44, -48, -78, -82};
        drawPg(g, x_coords, y_coords, x, y, a, Color.WHITE, Color.WHITE, 1.0f);
    }

    void drawCardUpperRight(Graphics g, int x, int y, double a) {
        drawCardUpper(g, x, y, a);
        int[] x_coords = new int[]{9, 13, 13, 9};
        int[] y_coords = new int[]{-82, -78, -48, -44};
        drawPg(g, x_coords, y_coords, x, y, a, Color.WHITE, Color.WHITE, 1.0f);
    }

    void drawCardFront(Graphics g, int x, int y, double a) {
        int[] x_coords = new int[]{30, 34, 34, 30, -30, -34, -34, -30};
        int[] y_coords = new int[]{48, 44, -44, -48, -48, -44, 44, 48};
        drawPg(g, x_coords, y_coords, x, y, a, Color.WHITE, Color.WHITE, 1.0f);
    }

    void drawCardStand(Graphics g, int x, int y, double a) {
        drawCardFlank(g, x, (int) (y - 16 * a), a);
        drawCardFront(g, x, y, a);
    }

    void drawCardReverseStand(Graphics g, int x, int y, double a) {
        drawCardFlank(g, x, (int) (y - 16 * a), a);
        drawCardBack(g, x, y, a);
    }

    void drawCardLaid(Graphics g, int x, int y, double a) {
        drawCardFlank(g, x, (int) (y + 16 * a), a);
        drawCardFront(g, x, y, a);
    }

    void drawCardReverseLaid(Graphics g, int x, int y, double a) {
        drawCardFlank(g, x, (int) (y + 16 * a), a);
        drawCardBack(g, x, y, a);
    }

    void drawCardBack(Graphics g, int x, int y, double a) {

        int[] x_coords = new int[]{30, 34, 34, 30, -30, -34, -34, -30};
        int[] y_coords = new int[]{48, 44, -44, -48, -48, -44, 44, 48};
        drawPg(g, x_coords, y_coords, x, y, a, new Color(150, 200, 50), Color.WHITE, 1.0f);

        int[] x_coords2 = new int[]{-15, -22, -12, -22, -8, -6, 4, 12, 20, 26, 24, 34, 27, 34, 22, 19, 6, 2, 0, -30, -6, -32, -12, -32, -17, -30, -15};
        int[] y_coords2 = new int[]{-4, -10, -12, -20, -20, -34, -27, -38, -22, -26, -15, -13, -8, 5, 8, 26, 17, 25, 16, 32, 15, 26, 8, 20, 2, 10, -4};
        drawPg(g, x_coords2, y_coords2, x, y, a, new Color(200, 160, 0), new Color(200, 160, 0), 1.0f);
        drawO(g, x, y, 483, 475, 43, a, new Color(180, 80, 0), new Color(180, 80, 0), 3.0f);
        int[] x_coords3 = new int[]{-15, 14, 25, 14, 4, 14, 12, -11, 12, 14, 12, 21, 12, 14, 12, 14, 13, -10, 13, 14, 13, 24, 13, 14};
        int[] y_coords3 = new int[]{-2, -8, -8, -8, -25, -8, -12, -18, -12, -8, -12, -16, -12, -8, 16, -8, -4, 12, -4, -8, -4, 2, -4, -8};
        drawPg(g, x_coords3, y_coords3, x, y, a, Color.WHITE, Color.BLACK, 3.0f);
    }

    void drawMJ9(Graphics g, int x, int y, double a) {
        int[] x_coords = new int[]{-20, -8, -20, -8, -13, -8, -6, -8, 0, 0, 0, 8, 6, 8, 8, 0, -4, 4, 16, 4, -4, 0, -8, -20, -8, -8, -13, -10, 8, 9, 20, 9, 14, 8, 14, 9, 8, -8};
        int[] y_coords = new int[]{14, 0, -4, 0, -14, -16, -4, -16, -10, -4, -10, -16, -6, -16, -24, -30, -34, -31, -38, -31, -34, -30, -24, -26, -24, -16, -18, 0, -2, -4, -4, -4, -20, -16, -20, -4, -2, 0};
        drawPg(g, x_coords, y_coords, x, y, a, Color.WHITE, new Color(0, 100, 0), 3.0f);

        int[] x_coords2 = new int[]{-8, -3, -5, 6, -4, 2, 4, 9, 4, 8, -8};
        int[] y_coords2 = new int[]{0, 26, 2, 42, 0, 4, 0, 36, 14, -2, 0};
        drawPg(g, x_coords2, y_coords2, x, y, a, Color.WHITE, new Color(0, 100, 0), 3.0f);

        drawO(g, x, y, 495, 475, 6, a, Color.WHITE, new Color(200, 50, 0), 3.0f);
        drawO(g, x, y, 475, 492, 7, a, Color.WHITE, new Color(0, 100, 0), 4.0f);
        drawO(g, x, y, 517, 492, 7, a, Color.WHITE, new Color(0, 100, 0), 4.0f);
    }

    void drawMJ32(Graphics g, int x, int y, double a) {
        int[] x_coords = new int[]{-15, -6, -6, 0, 8, 6, 8, 0, 6, 15, 13, 15, 6, 20, 26, 20, 6, 0, -6, -10, -18, -10, -13, -24, -13, -5, -6, -12, -6, -13, -6, -11, -16, -11, -6, -13, -6, -12, -6, -5, -13, -9, -6, -6, -15};
        int[] y_coords = new int[]{-20, -23, -19, -19, -24, -28, -24, -20, -15, -19, -23, -19, -15, -7, -7, -7, -15, -19, -19, -12, -13, -12, -4, 7, -4, -5, -1, 3, 3, 11, 10, 21, 16, 21, 10, 11, 3, 3, -1, -5, -4, -12, -19, -23, -20};
        drawPg(g, x_coords, y_coords, x, y, 1.1*a, Color.WHITE, new Color(0, 100, 0), 4.3f);

        int[] x_coords2 = new int[]{1, 1, 9, 9, 14, 10, 0, 10, 8, -4, 8, -3, 8, 20, 8, 10, 0, 9, 9, 1};
        int[] y_coords2 = new int[]{3, -7, -9, -1, -3, -1, 7, 5, 15, 7, 15, 19, 15, 23, 15, 5, 7, -1, -9, -7};
        drawPg(g, x_coords2, y_coords2, x, y, 1.1*a, Color.WHITE, new Color(0, 100, 0), 4.3f);
    }

    void drawMJ19(Graphics g, int x, int y, double a) {
        Graphics2D g2d = (Graphics2D) g;
        Stroke oldStroke = g2d.getStroke();
        Stroke newStroke = new BasicStroke((float) (a * 4.0f));
        g2d.setStroke(newStroke);

        int[] x_coords = new int[]{0, 3, 3, 0, -3, -3, 0};
        int[] y_coords = new int[]{37, 34, 10, 7, 10, 34, 37};
        drawPg(g, x_coords, y_coords, x, y, a, Color.WHITE, new Color(0, 100, 0), 4.0f);

        int[] x_coords3 = new int[]{0, 3, 3, 0, -3, -3, 0};
        int[] y_coords3 = new int[]{-33, -30, -6, -3, -6, -30, -33};
        drawPg(g, x_coords3, y_coords3, x, y, a, Color.WHITE, new Color(0, 100, 0), 4.0f);
    }

    void drawMJ18(Graphics g, int x, int y, double a) {
        int[] x_coords = new int[]{-20, -15, 15, 18, 10, -15};
        int[] y_coords = new int[]{-27, -26, -30, -26, -28, -26};
        drawPg(g, x_coords, y_coords, x, y, a, Color.WHITE, new Color(0, 0, 0), 4.0f);

        int[] x_coords2 = new int[]{-16, -12};
        int[] y_coords2 = new int[]{17, 30};
        drawPg(g, x_coords2, y_coords2, x, y, a, Color.WHITE, new Color(180, 20, 30), 4.0f);

        int[] x_coords3 = new int[]{6, -10, -12, -2, 3, -7, -9, -7, -6, -7, -17, -7, 3, 6, 3, 6, 3, 13, 3, -2, 6, 10, 6};
        int[] y_coords3 = new int[]{11, 13, 4, 2, -6, -4, -11, -4, 0, -4, -3, -4, -6, -11, -14, -11, -6, -7, -6, 2, 1, 4, 12};
        drawPg(g, x_coords3, y_coords3, x, y, a, Color.WHITE, new Color(180, 20, 30), 4.0f);

        int[] x_coords4 = new int[]{10, 15,18, 16, -1, -1, 8, 4, 8, 11, 8, -1, -10, -1, -1, -19, -1, -1, 4, -1, -8, -1, -1, -2, -1, -1, -1, 16,18, 15, 10};
        int[] y_coords4 = new int[]{30, 31,18, 16, 18, 23, 22, 19, 22, 26, 22, 23, 24, 23, 18, 22, 18, 7, 7, 7, 8, 7, 4, 2, 4, 7, 18,16, 18, 31, 30};
        drawPg(g, x_coords4, y_coords4, x, y, a, Color.WHITE, new Color(180, 20, 30), 4.0f);


    }
    void drawMJ0(Graphics g, int x, int y, double a) {

        drawO(g, x, y, 470, 470, 60, a, Color.WHITE, new Color(0, 100, 0), 4.0f);
        drawO(g, x, y, 479, 479, 42, a, Color.WHITE, new Color(0, 100, 0), 10.0f);
        drawO(g, x, y, 489, 489, 22, a, Color.WHITE, new Color(180, 20, 30), 4.0f);
        drawO(g, x, y, 491, 491, 8, a, Color.WHITE, new Color(180, 20, 30), 4.0f);
        drawO(g, x, y, 501, 491, 8, a, Color.WHITE, new Color(180, 20, 30), 4.0f);
        drawO(g, x, y, 491, 500, 8, a, Color.WHITE, new Color(180, 20, 30), 4.0f);
        drawO(g, x, y, 501, 500, 8, a, Color.WHITE, new Color(180, 20, 30), 4.0f);
        drawO(g, x, y, 497, 477, 6, a, Color.WHITE, new Color(230, 250, 230), 2.0f);
        drawO(g, x, y, 497, 516, 6, a, Color.WHITE, new Color(230, 250, 230), 2.0f);
        drawO(g, x, y, 486, 481, 6, a, Color.WHITE, new Color(230, 250, 230), 2.0f);
        drawO(g, x, y, 508, 481, 6, a, Color.WHITE, new Color(230, 250, 230), 2.0f);
        drawO(g, x, y, 508, 513, 6, a, Color.WHITE, new Color(230, 250, 230), 2.0f);
        drawO(g, x, y, 486, 513, 6, a, Color.WHITE, new Color(230, 250, 230), 2.0f);
        drawO(g, x, y, 479, 491, 6, a, Color.WHITE, new Color(230, 250, 230), 2.0f);
        drawO(g, x, y, 515, 491, 6, a, Color.WHITE, new Color(230, 250, 230), 2.0f);
        drawO(g, x, y, 515, 504, 6, a, Color.WHITE, new Color(230, 250, 230), 2.0f);
        drawO(g, x, y, 479, 503, 6, a, Color.WHITE, new Color(230, 250, 230), 2.0f);




    }

    void drawMJ8(Graphics g, int x, int y, double a) {
        drawO(g, x, y, 473, 491, 18, a, Color.WHITE, new Color(180, 20, 30), 3.0f);
        drawO(g, x, y, 477, 495, 10, a, Color.WHITE, new Color(180, 20, 30), 2.0f);
        drawO(g, x, y, 481, 499, 2, a, Color.WHITE, new Color(180, 20, 30), 2.0f);
        drawO(g, x, y, 491, 491, 18, a, Color.WHITE, new Color(180, 20, 30), 3.0f);
        drawO(g, x, y, 495, 495, 10, a, Color.WHITE, new Color(180, 20, 30), 2.0f);
        drawO(g, x, y, 499, 499, 2, a, Color.WHITE, new Color(180, 20, 30), 2.0f);
        drawO(g, x, y, 509, 491, 18, a, Color.WHITE, new Color(180, 20, 30), 3.0f);
        drawO(g, x, y, 513, 495, 10, a, Color.WHITE, new Color(180, 20, 30), 2.0f);
        drawO(g, x, y, 517, 499, 2, a, Color.WHITE, new Color(180, 20, 30), 2.0f);

        drawO(g, x, y, 473, 518, 18, a, Color.WHITE, new Color(0, 0, 0), 3.0f);
        drawO(g, x, y, 477, 522, 10, a, Color.WHITE, new Color(0, 0, 0), 2.0f);
        drawO(g, x, y, 481, 526, 2, a, Color.WHITE, new Color(0, 0, 0), 2.0f);
        drawO(g, x, y, 491, 518, 18, a, Color.WHITE, new Color(0, 0, 0), 3.0f);
        drawO(g, x, y, 495, 522, 10, a, Color.WHITE, new Color(0, 0, 0), 2.0f);
        drawO(g, x, y, 499, 526, 2, a, Color.WHITE, new Color(0, 0, 0), 2.0f);
        drawO(g, x, y, 509, 518, 18, a, Color.WHITE, new Color(0, 0, 0), 3.0f);
        drawO(g, x, y, 513, 522, 10, a, Color.WHITE, new Color(0, 0, 0), 2.0f);
        drawO(g, x, y, 517, 526, 2, a, Color.WHITE, new Color(0, 0, 0), 2.0f);

        drawO(g, x, y, 473, 464, 18, a, Color.WHITE, new Color(0, 100, 0), 3.0f);
        drawO(g, x, y, 477, 468, 10, a, Color.WHITE, new Color(0, 100, 0), 2.0f);
        drawO(g, x, y, 481, 472, 2, a, Color.WHITE, new Color(0, 100, 0), 2.0f);
        drawO(g, x, y, 491, 464, 18, a, Color.WHITE, new Color(0, 100, 0), 3.0f);
        drawO(g, x, y, 495, 468, 10, a, Color.WHITE, new Color(0, 100, 0), 2.0f);
        drawO(g, x, y, 499, 472, 2, a, Color.WHITE, new Color(0, 100, 0), 2.0f);
        drawO(g, x, y, 509, 464, 18, a, Color.WHITE, new Color(0, 100, 0), 3.0f);
        drawO(g, x, y, 513, 468, 10, a, Color.WHITE, new Color(0, 100, 0), 2.0f);
        drawO(g, x, y, 517, 472, 2, a, Color.WHITE, new Color(0, 100, 0), 2.0f);

    }

    void drawMJ33(Graphics g, int x, int y, double a) {
        int[] x_coords = new int[]{20,22,22,20,-20,-22,-22,-20};
        int[] y_coords = new int[]{-36,-34,35,37,37,35,-34,-36};
        drawPg(g, x_coords, y_coords, x, y, a, Color.WHITE, new Color(0, 0, 0), 4.0f);

        int[] x_coords2 = new int[]{17,17,-17,-17};
        int[] y_coords2 = new int[]{-31,32,32,-31};
        drawPg(g, x_coords2, y_coords2, x, y, a, Color.WHITE, new Color(0, 0, 0), 3.0f);

        int[] x_coords3 = new int[]{17,17,8};
        int[] y_coords3 = new int[]{-31,-22,-31};
        drawPg(g, x_coords3, y_coords3, x, y, a, Color.WHITE, new Color(0,0,0), 2.0f);

        int[] x_coords4 = new int[]{-17,-17,-8};
        int[] y_coords4 = new int[]{-31,-22,-31};
        drawPg(g, x_coords4, y_coords4, x, y, a, Color.WHITE, new Color(0,0,0), 2.0f);

        int[] x_coords5 = new int[]{-17,-17,-8};
        int[] y_coords5= new int[]{31,22,31};
        drawPg(g, x_coords5, y_coords5, x, y, a, Color.WHITE, new Color(0,0,0), 2.0f);

        int[] x_coords6 = new int[]{17,17,8};
        int[] y_coords6 = new int[]{31,22,31};
        drawPg(g, x_coords6, y_coords6, x, y, a, Color.WHITE, new Color(0,0,0), 2.0f);
    }
    void drawMJ28(Graphics g, int x, int y, double a) {
        int[] x_coords = new int[]{-7,-4,-11,-18,-11,-4,6,12,8,-3,-3,0,-4,-5,-5,-5,-6,-5,-4,-4,-7};
        int[] y_coords = new int[]{0,-15,-13,-13,-13,-15,-18,-17,-18,-16,-24,-25,-26,-29,-35,-29,-30,-31,-26,-17,0};
        drawPg(g, x_coords, y_coords, x, y, 0.9*a, Color.WHITE, new Color(0, 0, 0), 5f);

        int[] x_coords2 = new int[]{-6,-4,-6,-14,-6,9,-6,-3,-15,-3,8,-3,3,5,-7,-10,-19,-22,-17,-22,-23,-19,-22,-19,-10,-15,-10,-7,5,14,20,23,20,20,20,16,8,5};
        int[] y_coords2 = new int[]{15,29,15,18,15,12,15,6,10,6,5,6,-4,-3,0,1,4,6,29,6,4,4,6,4,1,-5,1,0,-2,-2,1,2,3,1,2,21,29,22};
        drawPg(g, x_coords2, y_coords2, x, y, 1*a, Color.WHITE, new Color(0, 0, 0), 5f);
    }

    protected void paintComponent(Graphics g) {

        g.setColor(new Color(0, 100, 60));
        g.fillRect(0, 0, 1280, 830);
        drawCardFront(g, x, y, a);
        drawMJ18(g, x, y, a);
        drawCardFront(g, x+100, y, a);
        drawMJ9(g,x+100,y,a);
        drawCardFront(g, x+200, y, a);
        drawMJ19(g,x+200,y,a);
        drawCardFront(g, x+300, y, a);
        drawMJ32(g,x+300,y,a);
        drawCardFront(g, x+400, y, a);
        drawMJ0(g,x+400,y,a);
        drawCardFront(g, x+500, y, a);
        drawMJ8(g,x+500,y,a);
        drawCardFront(g, x+600, y, a);
        drawMJ33(g,x+600,y,a);
        drawCardFront(g, x+700, y, a);
        drawMJ28(g,x+700,y,a);


    }
}
